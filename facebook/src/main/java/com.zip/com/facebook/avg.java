
package com.facebook;
  
import java.util.Scanner;

public class avg {

	public static void main(String[] args) {
//		int n, count = 1;   
//	      float  xF, averageF, sumF = 0;   
//	      Scanner sc = new Scanner(System.in);     
//	      System.out.println("Enter the value of n");  
//	      n = sc.nextInt();  
//	      while (count <= n)   
//	             {   
//	                  System.out.println(count);  
//	                  xF = sc.nextInt();  
//	                  sumF += xF;   
//	                  ++count;   
//	             }   
//	                  averageF = sumF/n;   
//	        System.out.println("The Average is"+averageF);  
//	    }   
		int a=3;
		int b=4;
		int c=5;
		int d=a+b+c;
		System.out.println(d/3);
		

	}
}


