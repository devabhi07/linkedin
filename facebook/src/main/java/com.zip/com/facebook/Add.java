package com.facebook;

public class Add {

	public static void main(String[] args) {
		int a=5;
		int b=6;
		System.out.println(a+b);
		// TODO Auto-generated method stub

	}

}
