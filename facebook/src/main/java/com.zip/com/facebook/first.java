package com.facebook;

public class first {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		for(int i=0;i<10;i++)
//			  System.out.println("REVATURE");
		int a=1;
		int b=5;
		System.out.println(a+b);
	
		
		
		// TODO Auto-generated method stub

	}

}
