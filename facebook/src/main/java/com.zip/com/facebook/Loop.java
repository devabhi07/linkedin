package com.facebook;

public class Loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0;i<10;i++)
		  System.out.println("REVATURE:");
		for(int j=0;j<10;j++)
		System.out.print("Revature:");
		

	}

}
